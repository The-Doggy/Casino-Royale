using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChipStack : MonoBehaviour
{
    // This is only here so that we're able to spawn chips
    // in when the player has it selected, the rest of the
    // functionality for these is located in Chip.cs and
    // RouletteManager.cs
    public GameObject SpawnChip;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
